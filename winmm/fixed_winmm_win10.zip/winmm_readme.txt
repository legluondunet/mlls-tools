TO INSTALL
Extract files from this archive into game directory; replacing the old winmm.dll.

Some games might have winmm.dll renamed to something else, such as win32.dll.


FIXES:
-game not starting on Windows 10
-tracks play 1 track too far